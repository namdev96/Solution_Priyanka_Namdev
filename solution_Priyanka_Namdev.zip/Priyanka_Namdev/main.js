const fs = require('fs');
const clickProcessor = require('./src/clickProcessor');
const periodAnalyzer = require('./src/periodAnalyzer');

const rawData = fs.readFileSync('clicks.json');
const clicks = JSON.parse(rawData);

const uniqueClicks = clickProcessor.removeDuplicates(clicks);
const clickPeriodsResult = periodAnalyzer.analyzeClickPeriods(uniqueClicks);

const resultData = {
  uniqueClicks,
  clickPeriods: clickPeriodsResult,
};

fs.writeFileSync('result-set.json', JSON.stringify(resultData, null, 2));
