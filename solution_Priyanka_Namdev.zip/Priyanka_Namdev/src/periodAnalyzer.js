module.exports = {
    analyzeClickPeriods: (clicks) => {
      const periodTotals = {};
  
      for (const click of clicks) {
        const timestamp = new Date(click.timestamp);
        const periodKey = `${timestamp.getHours()}:${timestamp.getMinutes()}:${timestamp.getSeconds()}`;
  console.log(periodKey)
        periodTotals[periodKey] = (periodTotals[periodKey] || 0) + click.amount;
      }
  
      const result = Object.keys(periodTotals).map((key) => ({
        period: key,
        totalAmount: periodTotals[key],
      }));
  
      return result;
    },
  };
  