const _ = require('lodash');

module.exports = {
  removeDuplicates: (clicks) => _.uniqBy(clicks, 'ip'),
};
