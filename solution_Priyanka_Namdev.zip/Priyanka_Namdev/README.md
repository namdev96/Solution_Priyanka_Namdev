# Click Analysis Solution

This repository contains a solution for the click analysis problem.

## Usage

To run the solution:

```bash
npm install
npm run solution
